
# TreesReborn

### Now with Ovens, Smelters, Braizers and Hottubs and Timed Torches

Replant trees automatically when they are cut down

- Trees are automatically replanted when cut down.
- no need for seeds
- compatible with plant everything and planting plus


 
[Chat with me on Discord](https://discord.com/users/TastyChickenLegs#4818)

### About the Mod:
Rebuild of Aedenthorns TreeRespawn for the newest version of Valheim
All credit goes back to Aeden



### Credits:

- Aedenthorn because without her code repository, I would have never understood how to do any of this.


### Configuration:



The config file is located in "<GameDirectory>\Bepinex\config" (You need to start the game at least once, with the mod installed to create the config file).

<b>To view or add items this mod affects:  </b>

See the images for a list of configurable items.



### Installation: (manual)  
Put on client and server.  Server will push down the settings and lock the config.

Extract DLL from zip file into "<GameDirectory>\Bepinex\plugins"  
Start the game.

### Version Information


1.0.0

- initial release

##	Now for the shameless plug

> ### My Other Mods:
>>* [No Smoke Stay Lit](https://valheim.thunderstore.io/package/TastyChickenLeg/NoSmokeStayLit/)
>>* [No Smoke Simplified](https://valheim.thunderstore.io/package/TastyChickenLegs/NoSmokeSimplified/)
>>* [Honey Please](https://valheim.thunderstore.io/package/TastyChickenLegs/HoneyPlease/)
>>* [Automatic Fuel](https://valheim.thunderstore.io/package/TastyChickenLeg/AutomaticFuel/)
>>* [Forsaken Powers Plus](https://valheim.thunderstore.io/package/TastyChickenLeg/ForsakenPowersPlus/)
>>* [Recycle Plus](https://valheim.thunderstore.io/package/TastyChickenLeg/RecyclePlus/)
>>* [Blast Furnace Takes All](https://valheim.thunderstore.io/package/TastyChickenLeg/BlastFurnaceTakesAll/)
>>* [Timed Torches Stay Lit](https://valheim.thunderstore.io/package/TastyChickenLeg/TimedTorchesStayLit/)
>>* [Drop More Loot](https://valheim.thunderstore.io/package/TastyChickenLegs/DropMoreLoot/)